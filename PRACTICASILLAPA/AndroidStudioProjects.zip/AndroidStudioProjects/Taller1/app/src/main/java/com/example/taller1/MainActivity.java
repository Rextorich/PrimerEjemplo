package com.example.taller1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_main);
    }

    public void onClick_linear_layout(View view) {
        Intent myIntent = new Intent(view.getContext(), Layout_Lineal.class);
        startActivityForResult(myIntent, 0);
    }

    public void onClick_layout_relativo(View view) {
        Intent myIntent = new Intent(view.getContext(), Layout_relativo.class);
        startActivityForResult(myIntent, 0);
    }

    public void onClick_tablas(View view) {
        Intent myIntent = new Intent(view.getContext(), Tablas.class);
        startActivityForResult(myIntent, 0);
    }

    public void onClick_Mezclar_layout(View view) {
        Intent myIntent = new Intent(view.getContext(), Mezclar_Layouts.class);
        startActivityForResult(myIntent, 0);
    }

    public void onClick_tam_pantalla(View view) {
        Intent myIntent = new Intent(view.getContext(), Tam_Pantalla.class);
        startActivityForResult(myIntent, 0);
    }

    public void onClick_incluir_layout(View view) {
        Intent myIntent = new Intent(view.getContext(), Botonera.class);
        startActivityForResult(myIntent, 0);
    }

    public void onClick_control_imagen(View view) {
        Intent myIntent = new Intent(view.getContext(), Control_Imagen.class);
        startActivityForResult(myIntent, 0);
    }

    public void onClick_densidad_imagen(View view) {
        Intent myIntent = new Intent(view.getContext(), Densidad_Imagen.class);
        startActivityForResult(myIntent, 0);
    }

    public void onClick_desplazamiento(View view) {
        Intent myIntent = new Intent(view.getContext(), Desplazamiento.class);
        startActivityForResult(myIntent, 0);
    }
}
