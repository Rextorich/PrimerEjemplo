package com.example.taller1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Control_Imagen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control__imagen);
    }
}
