package com.example.taller1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Densidad_Imagen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_densidad__imagen);
    }
}
