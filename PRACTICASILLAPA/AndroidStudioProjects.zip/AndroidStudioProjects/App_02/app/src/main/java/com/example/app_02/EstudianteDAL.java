package com.example.app_02;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.ArrayAdapter;

public class EstudianteDAL {

    private SQLiteDatabase sql;
    private Context context;
    private DataBase baseDatos;

    public EstudianteDAL(Context context) {
        this.context = context;
    }

    public void abrir() {

        // CREAR LA DB
        baseDatos = new DataBase(context, "DB_Estudiante", null, 1);

        // Abrir la db => { lectura, escritura }
        sql = baseDatos.getWritableDatabase();
    }

    public void cerrar() {
        sql.close();
    }

    public boolean insertEstudiante(Estudiante estudiante) {

        try {
            abrir();

            ContentValues row = new ContentValues();

            row.put("nombre", estudiante.getNombre());
            row.put("apellido", estudiante.getApellido());
            row.put("telefono", estudiante.getTelefono());
            row.put("correo", estudiante.getEmail());

            long cantidad = sql.insert("Estudiantes", null, row);

            cerrar();

            return (cantidad >= 1) ? true : false;

        } catch (Exception e) {
            this.cerrar();
            return false;
        }
    }

    public Estudiante findEstudiante(String codigo) {

        this.abrir();

        //String sql = String.format("SELECT nombre, apellido, telefono, corredo FROM Estudiantes WHERE codigo = {0}", codigo);
        String query = "SELECT nombre, apellido, telefono, correo, codigo FROM Estudiantes WHERE apellido LIKE ?";

        //String[] param = new String[1];

        //param[0]= Integer.toString(cantidad,10);

        // Cursor = (DataReader)
        Cursor cursor = sql.rawQuery(query, new String[]{codigo});

        Estudiante estudiante = null;

        if (cursor.moveToFirst()) {
            estudiante = new Estudiante(
                    Integer.parseInt(cursor.getString(4)),
                    cursor.getString(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    cursor.getString(3)
            );
        }

        this.cerrar();
        return estudiante;
    }

    public boolean deleteEstudiante(String codigo) {

        try {
            this.abrir();

            int cantidad = sql.delete("Estudiantes", "codigo = ", new String[]{codigo});

            this.cerrar();

            return (cantidad >= 1) ? true : false;
        } catch (Exception e) {
            this.cerrar();
            return false;
        }

    }

    public boolean updateEstudiante(Estudiante estudiante) {

        try {
            this.abrir();

            ContentValues row = new ContentValues();

            row.put("nombre", estudiante.getNombre());
            row.put("apellido", estudiante.getApellido());
            row.put("telefono", estudiante.getTelefono());
            row.put("correo", estudiante.getEmail());

            int cantidad = sql.update("Estudiante", row, "codigo = ", new String[]{String.valueOf(estudiante.getCodigo())});

            this.cerrar();

            return (cantidad >= 1) ? true : false;
        } catch (Exception e) {
            this.cerrar();
            return false;
        }

    }
}
