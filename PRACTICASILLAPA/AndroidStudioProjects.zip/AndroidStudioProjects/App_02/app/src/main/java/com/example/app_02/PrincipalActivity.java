package com.example.app_02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class PrincipalActivity extends AppCompatActivity implements View.OnClickListener {

    private TextView TextView_Title;
    private TextView TextView_user;
    private String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        TextView_user = findViewById(R.id.user_);

        Intent myIntent = getIntent(); // gets the previously created intent

        String user = myIntent.getStringExtra("usuario"); // will return "FirstKeyValue"
        String password = myIntent.getStringExtra("password"); // will return "SecondKeyValue

        TextView_user.setText(user + " - " + password);
        //TextView=findViewById(R.id.)
    }

    @Override
    public void onClick(View view) {

    }
}
