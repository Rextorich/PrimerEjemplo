package com.example.app_02;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.btn_Ingreso)
    Button btnIngreso;
    //Declarar variables
    private EditText EditText_Usuario;
    private EditText EditText_Password;
    private Button Button_Ingresar;

    private DataBase dataBase;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        dataBase = new DataBase(this, "base_estudiantes", null, 1);

        //Instanciar Objetos
        EditText_Usuario = findViewById(R.id.txt_User);
        EditText_Password = findViewById(R.id.txt_Password);
        Button_Ingresar = findViewById(R.id.btn_Ingreso);
    }

    public void click_Ingresar(View view) {
        String usuario = EditText_Usuario.getText().toString();
        String password = EditText_Password.getText().toString();

        if (usuario.equals("octavo") && password.equals("octavo")) {

        } else {
            Toast.makeText(this, "Datos incorrectos", Toast.LENGTH_LONG).show();
        }
    }

    @OnClick(R.id.btn_Ingreso)
    public void onViewClicked() {

        String usuario = EditText_Usuario.getText().toString();
        String password = EditText_Password.getText().toString();


        try {
            String sql = "SELECT codigo_estudiante, usuario, password FROM Usuario WHERE usuario = ? AND password = ? ";

            db = dataBase.getReadableDatabase();
            Cursor cursor = db.rawQuery(sql, new String[]{usuario, password});

            if (!cursor.moveToFirst()) {
                Toast.makeText(getBaseContext(), "No existe ningun registro", Toast.LENGTH_LONG).show();
                db.close();
                //ingresarAdmin();
                return;
            }
        } catch (Exception e) {
            Toast.makeText(getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
            Log.println(1, "log", e.getMessage());
        }

        Intent intent = new Intent(getApplicationContext(), MenuActivity.class);

        //ENVIAR PARAMETROS
        intent.putExtra("usuario", usuario);
        intent.putExtra("password", password);

        startActivity(intent);

    }

    private void ingresarAdmin() {
        db = dataBase.getWritableDatabase();

        ContentValues row = new ContentValues();

        row.put("usuario", "admin");
        row.put("password", "admin");

        db.insert("Usuario", null, row);

        db.close();
    }
}
