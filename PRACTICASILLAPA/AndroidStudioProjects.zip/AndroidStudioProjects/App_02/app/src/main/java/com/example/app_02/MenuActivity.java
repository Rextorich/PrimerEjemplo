package com.example.app_02;

import android.content.ContentValues;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class MenuActivity extends AppCompatActivity {

    @BindView(R.id.EditText_codigo)
    EditText EditTextCodigo;
    @BindView(R.id.EditText_nombre)
    EditText EditTextNombre;
    @BindView(R.id.editText_apellido)
    EditText editTextApellido;
    @BindView(R.id.EditText_telefono)
    EditText EditTextTelefono;
    @BindView(R.id.EditText_correo)
    EditText EditTextCorreo;
    @BindView(R.id.button_ingresar)
    Button buttonIngresar;
    @BindView(R.id.button_buscar)
    Button buttonBuscar;
    @BindView(R.id.button_eliminar)
    Button buttonEliminar;
    @BindView(R.id.button_modificar)
    Button buttonModificar;

    DataBase dataBase;
    SQLiteDatabase db;
    EstudianteDAL estudianteDAL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        ButterKnife.bind(this);

        //Creacion de la DB
        dataBase = new DataBase(this, "base_estudiantes", null, 1);

        estudianteDAL = new EstudianteDAL(this);
    }

    @OnClick(R.id.button_ingresar)
    public void onButtonIngresarClicked() {

        String codigo = EditTextCodigo.getText().toString();
        String nombre = EditTextNombre.getText().toString();
        String apellido = editTextApellido.getText().toString();
        String telefono = EditTextTelefono.getText().toString();
        String correo = EditTextCorreo.getText().toString();

        Estudiante estudiante = new Estudiante(
                Integer.parseInt(codigo),
                nombre, apellido, telefono, correo
        );

        boolean incertado = estudianteDAL.insertEstudiante(estudiante);

        if (incertado) {
            Toast.makeText(this, "Estudiante insertado", Toast.LENGTH_LONG);
        } else {
            Toast.makeText(this, "No incertado", Toast.LENGTH_LONG);
        }

        /*
        //Abrir la base de datos(lectura o escritura)
        db = dataBase.getWritableDatabase();



        //String sql = String.format("INSERT INTO Estudiantes (nombre, apellido, telefono, correo) VALUES({0},{1},{2},{3})", nombre, apellido, telefono, correo);
        //db.execSQL(sql);

        ContentValues row = new ContentValues();

        row.put("nombre", nombre);
        row.put("apellido", apellido);
        row.put("telefono", telefono);
        row.put("correo", correo);

        db.insert("Estudiantes", null, row);

        db.close();

        ClearFields();

        Toast.makeText(this, "Usuario insertado correctamente", Toast.LENGTH_LONG).show();

         */
    }

    private void ClearFields() {
        EditTextCodigo.setText("");
        EditTextNombre.setText("");
        editTextApellido.setText("");
        EditTextTelefono.setText("");
        EditTextCorreo.setText("");
    }

    @OnClick(R.id.button_buscar)
    public void onButtonBuscarClicked() {

        String codigo = editTextApellido.getText().toString();

        estudianteDAL.findEstudiante(codigo);

//        db = dataBase.getReadableDatabase();
//
//        String codigo = editTextApellido.getText().toString();
//
//        //String sql = String.format("SELECT nombre, apellido, telefono, corredo FROM Estudiantes WHERE codigo = {0}", codigo);
//        String sql = "SELECT nombre, apellido, telefono, correo, codigo FROM Estudiantes WHERE apellido LIKE ?";
//
//        //String[] param = new String[1];
//
//        //param[0]= Integer.toString(cantidad,10);
//
//        // Cursor = (DataReader)
//        Cursor cursor = db.rawQuery(sql, new String[]{codigo});
//
//        if (!cursor.moveToFirst()) {
//            Toast.makeText(this, "No existe ningun registro", Toast.LENGTH_LONG).show();
//            ClearFields();
//            return;
//        }
//
//        EditTextNombre.setText(cursor.getString(0));
//        editTextApellido.setText(cursor.getString(1));
//        EditTextTelefono.setText(cursor.getString(2));
//        EditTextCorreo.setText(cursor.getString(3));
//        EditTextCodigo.setText(cursor.getString(4));
//
//        db.close();
//        cursor.close();
    }

    @OnClick(R.id.button_eliminar)
    public void onButtonEliminarClicked() {
        db = dataBase.getReadableDatabase();

        String codigo = EditTextCodigo.getText().toString();

        int cantidad = db.delete("Estudiantes", "codigo = ", new String[]{codigo});

        if (cantidad <= 0) {
            Toast.makeText(this, "No existe ningun registro", Toast.LENGTH_LONG).show();
            return;
        }

        db.close();

        Toast.makeText(this, "Registro eliminado!", Toast.LENGTH_LONG).show();
        ClearFields();
    }

    @OnClick(R.id.button_modificar)
    public void onButtonModificarClicked() {
        db = dataBase.getReadableDatabase();

        String codigo = EditTextCodigo.getText().toString();
        String nombre = EditTextNombre.getText().toString();
        String apellido = editTextApellido.getText().toString();
        String telefono = EditTextTelefono.getText().toString();
        String correo = EditTextCorreo.getText().toString();

        ContentValues row = new ContentValues();

        row.put("nombre", nombre);
        row.put("apellido", apellido);
        row.put("telefono", telefono);
        row.put("correo", correo);
        //row.put("codigo", codigo);

        int cantidad = db.update("Estudiante", row, "codigo = ", new String[]{codigo});

        if (cantidad <= 0) {
            Toast.makeText(this, "No existe ningun registro", Toast.LENGTH_LONG).show();
            return;
        }

        db.close();

        Toast.makeText(this, "Registro actualizado!", Toast.LENGTH_LONG).show();
        ClearFields();
    }
}
