package com.example.app_02;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataBase extends SQLiteOpenHelper {

    private String create_table_student = "" +
            "CREATE TABLE Estudiantes(" +
            "codigo Interger Primary Key, " +
            "nombre Text, " +
            "apellido Text, " +
            "telefono Text, " +
            "correo Text)";

    private String create_table_user = "" +
            "CREATE TABLE Usuario(" +
            "codigo_estudiante Integer," +
            "usuario Text," +
            "password Text)";

    public DataBase(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    // CREACION DE LAS ESTRUCTURA DE LA DB
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(create_table_student);
        db.execSQL(create_table_user);
    }

    // SE UTILIZA CUANDO SE HAGA CAMBIOS EN LA ESTRUCTURA DE LA DB
    // POR LO TANDO HAY QUE ACTUALIZAR LA DB
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        // Borra la tabla Estudiantes
        db.execSQL("DROP TABLE IF EXISTS Estudiantes");
        db.execSQL("DROP TABLE IF EXISTS Usuario");

        // Actualizar la estructura de la base de datos.
        db.execSQL(create_table_student);
        db.execSQL(create_table_user);
    }
}
