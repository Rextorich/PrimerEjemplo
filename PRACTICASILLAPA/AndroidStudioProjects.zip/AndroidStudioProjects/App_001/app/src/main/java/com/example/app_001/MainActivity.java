package com.example.app_001;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText EditText_base;
    private EditText EditText_exponente;

    private TextView TextView_resultado;

    private Button Button_calcular;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_main);

        EditText_base = findViewById(R.id.editText_base);
        EditText_exponente = findViewById(R.id.editText_exponente);

    }


    public void onClick_calcular(View view) {

        int base = Integer.parseInt(EditText_base.getText().toString());
        int exponente = Integer.parseInt(EditText_exponente.getText().toString());

        long resultado = 1;

        for (int i = 1; i <= exponente; i++) {
            resultado *= base;
        }

        TextView_resultado.setText(String.valueOf(resultado ));
    }
}
