package com.example.login

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.JsonReader
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import okhttp3.*
import org.json.JSONObject

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import android.R.attr.password
import android.content.Intent
import androidx.core.app.ComponentActivity.ExtraData
import androidx.core.content.ContextCompat.getSystemService
import android.icu.lang.UCharacter.GraphemeClusterBreak.T


class MainActivity : AppCompatActivity() {

    private lateinit var et_usuario: EditText
    private lateinit var et_password: EditText
    private lateinit var btb_login: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        et_usuario = findViewById(R.id.editText_usuario)
        et_password = findViewById(R.id.editText_password)
        btb_login = findViewById(R.id.button_login)


    }

    fun login(view: View) {
        val serverURL: String = "https://fast-food-em.000webhostapp.com/api/login"
        //val serverURL: String = "https://reqres.in/api/users?page=2"

        var usuario: String = et_usuario.text.toString()
        var password: String = et_password.text.toString()

        var json: JSONObject = JSONObject()

        json.put("email", usuario)
        json.put("password", password)
        json.put("access_token", "true")

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val requestBody = json.toString().toRequestBody(mediaType)


        val request = Request.Builder()
            .url(serverURL)
            .post(requestBody)
            .build()

        /*
        val request = Request.Builder()
            .url(serverURL)
            .build()
        */

        var client = OkHttpClient()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                //Toast.makeText(baseContext, e.message, Toast.LENGTH_LONG)
                print(e.message)
                Log.d("myTag", e.message.toString());
            }

            override fun onResponse(call: Call, response: Response) {

                val intent = Intent(applicationContext, PrincipalActivity::class.java)

                startActivity(intent)
            }
        })
    }
}

