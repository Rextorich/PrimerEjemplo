package com.example.illapa_luis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class LI_Facturacion extends AppCompatActivity {

    private EditText EditText_codigo_producto;
    private EditText EditText_cantidad;
    private EditText EditText_total;
    private float total;
    private List<Producto> list_productos;
    private int tam;

    DataBase dataBase;
    SQLiteDatabase db;
    FacturacionDAL facturacionDAL;
    Cliente cliente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_li__facturacion);

        EditText_total = findViewById(R.id.editText_total);

        dataBase = new DataBase(this, "base_facturacion", null, 1);
        facturacionDAL = new FacturacionDAL(this);

        total = 0;

        list_productos = new ArrayList<>();

        Intent myIntent = getIntent();

        ArrayList<String> codigos = myIntent.getStringArrayListExtra("list");


        tam = codigos.size();

        loadClient();
        loadTable(codigos);

    }

    private void loadClient() {
        cliente = facturacionDAL.findClient("1");

        TextView tv = findViewById(R.id.textView_cliente);

        tv.setText(cliente.getNombre() + " " + cliente.getApellido());
    }

    private void loadTable(ArrayList<String> codigos) {

        TableLayout table = findViewById(R.id.data_set);

        dataBase = new DataBase(this, "base_facturacion", null, 1);
        facturacionDAL = new FacturacionDAL(this);

        for (int i = 0; i < codigos.size(); i++) {

            Producto p = facturacionDAL.findProducto(codigos.get(i));

            TableRow.LayoutParams paramsExample = new TableRow.LayoutParams(
                    TableRow.LayoutParams.WRAP_CONTENT,
                    TableRow.LayoutParams.WRAP_CONTENT, 1.0f);

            TableRow tr = new TableRow(this);
            tr.setLayoutParams(new TableRow.LayoutParams(
                    TableRow.LayoutParams.FILL_PARENT,
                    TableRow.LayoutParams.WRAP_CONTENT
            ));

            TextView tv_nombre = new TextView(this);
            tv_nombre.setGravity(Gravity.CENTER);
            tv_nombre.setLayoutParams(paramsExample);

            TextView tv_precio = new TextView(this);
            tv_precio.setGravity(Gravity.CENTER);
            tv_precio.setLayoutParams(paramsExample);

            EditText et = new EditText(this);
            et.setGravity(Gravity.CENTER);
            et.setLayoutParams(paramsExample);

            tv_nombre.setText(p.getNombre());
            tv_precio.setText(String.valueOf(p.getPrecio()));

            tr.addView(tv_nombre);
            tr.addView(tv_precio);

            tr.addView(et);

            table.addView(tr);

            total += p.getPrecio();

        }

        EditText_total.setText(String.valueOf(total));

    }

    public void onClick_recalcualar(View view) {


    }

    public void onClick_open_save(View v) {

        facturacionDAL.saveFactura();
    }

    public void onClick_open(View view) {

        String codigo = EditText_codigo_producto.getText().toString();
        String cantidad = EditText_cantidad.getText().toString();

        Producto p = facturacionDAL.findProducto(codigo);

        if (p != null) {
            TableLayout table = findViewById(R.id.data_set);
            table.setGravity(Gravity.CENTER);

            TableRow tr = new TableRow(this);
            tr.setGravity(Gravity.CENTER);

            TextView tv_nombre = new TextView(this);
            //tv_nombre.setGravity(Gravity.LEFT);

            TextView tv_precio = new TextView(this);

            TextView tv_cantidad = new TextView(this);
            //tv_precio.setGravity(Gravity.CENTER);


            tv_nombre.setText(p.getNombre());
            tv_precio.setText(String.valueOf(p.getPrecio()));
            tv_cantidad.setText(cantidad);

            tr.addView(tv_nombre);
            tr.addView(tv_precio);
            tr.addView(tv_cantidad);
            //tr.addView(tv1);
            //tr[1].addView(tv1);

            table.addView(tr);

            total += p.getPrecio() * Float.parseFloat(cantidad);
            EditText_total.setText(String.valueOf(total));
            this.list_productos.add(p);


        } else {
            Toast.makeText(this, "No se ha encontrado el producto con el id: " + codigo, Toast.LENGTH_LONG).show();
        }

    }

}
