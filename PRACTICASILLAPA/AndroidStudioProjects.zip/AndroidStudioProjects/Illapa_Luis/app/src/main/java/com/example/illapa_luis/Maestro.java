package com.example.illapa_luis;

import java.util.List;

public class Maestro {
    private int id;
    private List<Detalle> Detalle;
    private Cliente cliente;

    public Maestro() {

    }

    public Maestro(int id, List<com.example.illapa_luis.Detalle> detalle, Cliente cliente) {
        this.id = id;
        Detalle = detalle;
        this.cliente = cliente;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<com.example.illapa_luis.Detalle> getDetalle() {
        return Detalle;
    }

    public void setDetalle(List<com.example.illapa_luis.Detalle> detalle) {
        Detalle = detalle;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
}
