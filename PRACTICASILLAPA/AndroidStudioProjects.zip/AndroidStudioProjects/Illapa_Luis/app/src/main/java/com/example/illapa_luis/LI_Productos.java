package com.example.illapa_luis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LI_Productos extends AppCompatActivity {


    DataBase dataBase;
    SQLiteDatabase db;
    FacturacionDAL facturacionDAL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_li__productos);

        LoadData();
    }


    private void LoadData() {
        dataBase = new DataBase(this, "base_facturacion", null, 1);
        facturacionDAL = new FacturacionDAL(this);

        List<Producto> list = facturacionDAL.getAllProducto();

        TableLayout table = findViewById(R.id.data_set_all_products);
        table.setGravity(Gravity.CENTER);

        Producto p;

        for (int i = 0; i < list.size(); i++) {

            TableRow.LayoutParams paramsExample = new TableRow.LayoutParams(
                    TableRow.LayoutParams.WRAP_CONTENT,
                    TableRow.LayoutParams.WRAP_CONTENT, 1.0f);

            TableRow tr = new TableRow(this);
            tr.setLayoutParams(new TableRow.LayoutParams(
                    TableRow.LayoutParams.FILL_PARENT,
                    TableRow.LayoutParams.WRAP_CONTENT
            ));

            TextView tv_nombre = new TextView(this);
            tv_nombre.setGravity(Gravity.CENTER);
            tv_nombre.setLayoutParams(paramsExample);

            Button button_com = new Button(this);
            button_com.setGravity(Gravity.CENTER);
            button_com.setLayoutParams(paramsExample);

            button_com.setText("Comprar");

            p = list.get(i);

            tv_nombre.setText(p.getNombre());

            tr.addView(tv_nombre);
            tr.addView(button_com);

            final Producto finalP = p;
            final List<Producto> list_comprados = this.list_comprados;
            button_com.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    list_comprados.add(finalP);
                    v.setEnabled(false);
                }
            });

            table.addView(tr);
        }
    }

    List<Producto> list_comprados = new ArrayList<>();

    public void onClick_open(View view) {
        Intent myIntent = new Intent(view.getContext(), LI_Facturacion.class);

        ArrayList<String> codigos = new ArrayList<>();

        for (int i = 0; i < list_comprados.size(); i++) {
            codigos.add(String.valueOf(list_comprados.get(i).getId()));
        }

        myIntent.putStringArrayListExtra("list", codigos);

        startActivityForResult(myIntent, 0);
    }
}
