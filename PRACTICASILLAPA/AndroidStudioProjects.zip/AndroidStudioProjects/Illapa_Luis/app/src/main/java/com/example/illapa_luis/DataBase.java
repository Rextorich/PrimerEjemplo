package com.example.illapa_luis;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataBase extends SQLiteOpenHelper {


    private String create_table_producto = "CREATE TABLE producto(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, nombre Text, precio Real)";
    private String create_table_cliente = "CREATE TABLE cliente(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, nombre Text, apellido Text)";
    private String create_table_maestro = "CREATE TABLE maestro(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, id_cliente Integer, total Real)";
    private String create_table_detalle = "CREATE TABLE detalle(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, id_producto Integer, cantidad Real)";

    public DataBase(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(create_table_producto);
        db.execSQL(create_table_cliente);
        db.execSQL(create_table_maestro);
        db.execSQL(create_table_detalle);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // Borra la tabla Estudiantes
        db.execSQL("DROP TABLE IF EXISTS producto");
        db.execSQL("DROP TABLE IF EXISTS cliente");
        db.execSQL("DROP TABLE IF EXISTS maestro");
        db.execSQL("DROP TABLE IF EXISTS detalle");

        // Actualizar la estructura de la base de datos.
        db.execSQL(create_table_producto);
        db.execSQL(create_table_cliente);
        db.execSQL(create_table_maestro);
        db.execSQL(create_table_detalle);
    }
}
