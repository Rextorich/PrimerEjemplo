package com.example.illapa_luis;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class FacturacionDAL {
    private SQLiteDatabase sql;
    private Context context;
    private DataBase baseDatos;

    public FacturacionDAL(Context context) {
        this.context = context;
    }

    public void abrir() {

        // CREAR LA DB
        baseDatos = new DataBase(context, "DB_Estudiante", null, 1);

        // Abrir la db => { lectura, escritura }
        sql = baseDatos.getWritableDatabase();
    }

    public void cerrar() {
        sql.close();
    }

    public ArrayList<Producto> getAllProducto() {
        this.abrir();

        String query = "SELECT id, nombre, precio FROM producto";

        Cursor cursor = sql.rawQuery(query, null);

        Producto producto = null;

        ArrayList<Producto> list = new ArrayList<>();

        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                producto = new Producto(
                        Integer.parseInt(cursor.getString(0)),
                        cursor.getString(1),
                        Float.parseFloat(cursor.getString(2))
                );

                list.add(producto);

                cursor.moveToNext();
            }
        }
        cursor.close();

        this.cerrar();
        return list;
    }

    public boolean saveProducto(Producto p) {
        try {
            abrir();

            ContentValues row = new ContentValues();

            row.put("nombre", p.getNombre());
            row.put("precio", p.getPrecio());

            long cantidad = sql.insert("producto", null, row);

            cerrar();

            return (cantidad >= 1) ? true : false;

        } catch (Exception e) {
            this.cerrar();
            return false;
        }
    }

    public boolean saveCliente(Cliente c) {
        try {
            abrir();

            ContentValues row = new ContentValues();

            row.put("nombre", c.getNombre());
            row.put("apellido", c.getApellido());

            long cantidad = sql.insert("cliente", null, row);

            cerrar();

            return (cantidad >= 1) ? true : false;

        } catch (Exception e) {
            this.cerrar();
            return false;
        }
    }

    public Producto findProducto(String codigo) {

        this.abrir();

        String query = "SELECT id, nombre, precio FROM producto WHERE id LIKE ?";

        Cursor cursor = sql.rawQuery(query, new String[]{codigo});

        Producto producto = null;

        if (cursor.moveToFirst()) {
            producto = new Producto(
                    Integer.parseInt(cursor.getString(0)),
                    cursor.getString(1),
                    Float.parseFloat(cursor.getString(2))
            );
        }

        this.cerrar();
        return producto;
    }

    public boolean insertMaestro(float total, int id_cliente) {
        return true;
    }

    public Cliente findClient(String codigo) {
        this.abrir();

        String query = "SELECT id, nombre, apellido FROM cliente WHERE id LIKE ?";

        Cursor cursor = sql.rawQuery(query, new String[]{codigo});

        Cliente cliente = null;

        if (cursor.moveToFirst()) {
            cliente = new Cliente(
                    Integer.parseInt(cursor.getString(0)),
                    cursor.getString(1),
                    cursor.getString(2)
            );
        }

        this.cerrar();
        return cliente;
    }

    public boolean saveFactura(Cliente c, float total) {
        try {
            abrir();

            ContentValues row = new ContentValues();

            row.put("total", total);
            row.put("id_cliente", c.getId());

            long cantidad = sql.insert("maestro", null, row);

            cerrar();

            return (cantidad >= 1) ? true : false;

        } catch (Exception e) {
            this.cerrar();
            return false;
        }
    }

    public int getLastIdFactura() {
        try {
            this.abrir();

            String query = "SELECT id FROM maestro ORDER BY id DESC LIMIT 1";

            Cursor cursor = sql.rawQuery(query, null);

            int id;

            if (cursor.moveToFirst()) {
                id = Integer.parseInt(cursor.getString(0));
            }

            this.cerrar();

            return id;

        } catch (Exception e) {
            this.cerrar();
            return -1;
        }
    }
}
