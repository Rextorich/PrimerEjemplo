package com.example.illapa_luis;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    DataBase dataBase;
    SQLiteDatabase db;
    FacturacionDAL facturacionDAL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //dataBase = new DataBase(this, "base_facturacion", null, 1);
        //facturacionDAL = new FacturacionDAL(this);

        //creacionClientes();
    }

    private void creacionClientes() {

        Cliente c1 = new Cliente("Juan", "Martinez");

        Producto p1 = new Producto("Coca Cola", 2.3f);
        Producto p2 = new Producto("Manicho", 0.5f);
        Producto p3 = new Producto("Aceite", 0.9f);
        Producto p4 = new Producto("Jugo Naranja 1 ltr", 0.6f);
        Producto p5 = new Producto("Ruffles", 0.45f);

        facturacionDAL.abrir();

        boolean op_c1 = facturacionDAL.saveCliente(c1);

        boolean op_p1 = facturacionDAL.saveProducto(p1);
        boolean op_p2 = facturacionDAL.saveProducto(p2);
        boolean op_p3 = facturacionDAL.saveProducto(p3);
        boolean op_p4 = facturacionDAL.saveProducto(p4);
        boolean op_p5 = facturacionDAL.saveProducto(p5);

    }

    public void onClick_open(View view) {
        Intent myIntent = new Intent(view.getContext(), LI_Productos.class);
        startActivityForResult(myIntent, 0);
    }

}
